-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 15 jan. 2019 à 15:46
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `teamfinder`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `ID_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `CAT_Nom` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_categorie`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`ID_categorie`, `CAT_Nom`) VALUES
(1, 'Environnement\r\n'),
(2, 'Informatique\r\n'),
(5, 'Jeux-vidéos\r\n'),
(6, 'Electronique\r\n'),
(7, 'Batiment\r\n'),
(8, 'Automobile\r\n'),
(9, 'Menuiserie\r\n'),
(10, 'Architecture\r\n'),
(11, 'Art & Culture\r\n'),
(12, 'Communication\r\n'),
(13, 'Mecanique\r\n'),
(14, 'Sport\r\n'),
(15, 'Humanitaire\r\n'),
(16, 'Science\r\n'),
(17, 'Autres');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `ID_Com` int(11) NOT NULL AUTO_INCREMENT,
  `COM_Autheur` int(11) NOT NULL,
  `COM_Msg` text NOT NULL,
  `COM_Projet` int(11) NOT NULL,
  `COM_Date` datetime NOT NULL,
  PRIMARY KEY (`ID_Com`),
  KEY `COM_Autheur` (`COM_Autheur`,`COM_Projet`),
  KEY `COM_Projet` (`COM_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `commentairereponse`
--

DROP TABLE IF EXISTS `commentairereponse`;
CREATE TABLE IF NOT EXISTS `commentairereponse` (
  `CR_ID` int(11) NOT NULL,
  `CR_Autheur` int(11) NOT NULL,
  `CR_Msg` text NOT NULL,
  `CR_Projet` int(11) NOT NULL,
  `CR_Date` datetime NOT NULL,
  `ID_Com` int(11) NOT NULL,
  PRIMARY KEY (`CR_ID`),
  KEY `CR_Autheur` (`CR_Autheur`),
  KEY `CR_Projet` (`CR_Projet`),
  KEY `ID_Com` (`ID_Com`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `Id_Membre` int(11) NOT NULL AUTO_INCREMENT,
  `M_User` int(11) NOT NULL,
  `M_Projet` int(11) NOT NULL,
  `M_Attente` tinyint(1) NOT NULL,
  PRIMARY KEY (`Id_Membre`),
  KEY `M_User` (`M_User`,`M_Projet`),
  KEY `M_Projet` (`M_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`Id_Membre`, `M_User`, `M_Projet`, `M_Attente`) VALUES
(15, 13, 11, 0),
(17, 11, 12, 0),
(20, 13, 12, 1),
(22, 11, 11, 0),
(23, 14, 11, 1),
(24, 11, 19, 0),
(25, 14, 23, 1),
(26, 14, 21, 1);

-- --------------------------------------------------------

--
-- Structure de la table `messageprive`
--

DROP TABLE IF EXISTS `messageprive`;
CREATE TABLE IF NOT EXISTS `messageprive` (
  `ID_MP` int(11) NOT NULL AUTO_INCREMENT,
  `MP_Sujet` varchar(255) NOT NULL,
  `MP_Msg` text NOT NULL,
  `MP_Author` int(11) NOT NULL,
  `MP_Destinataire` int(11) NOT NULL,
  `MP_Date` datetime NOT NULL,
  PRIMARY KEY (`ID_MP`),
  KEY `MP_Author` (`MP_Author`,`MP_Destinataire`),
  KEY `MP_Destinataire` (`MP_Destinataire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `piecejointe`
--

DROP TABLE IF EXISTS `piecejointe`;
CREATE TABLE IF NOT EXISTS `piecejointe` (
  `ID_PieceJointe` int(11) NOT NULL AUTO_INCREMENT,
  `PJ_Fichier` varchar(255) NOT NULL,
  `PJ_Projet` int(11) NOT NULL,
  `PJ_Libelle` varchar(255) NOT NULL,
  `PJ_Date` date NOT NULL,
  PRIMARY KEY (`ID_PieceJointe`),
  KEY `PJ_Projet` (`PJ_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `piecejointe`
--

INSERT INTO `piecejointe` (`ID_PieceJointe`, `PJ_Fichier`, `PJ_Projet`, `PJ_Libelle`, `PJ_Date`) VALUES
(3, 'Conduite-de-projet.pptx', 11, 'Diaporama', '2019-01-15');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

DROP TABLE IF EXISTS `projet`;
CREATE TABLE IF NOT EXISTS `projet` (
  `ID_Projet` int(11) NOT NULL AUTO_INCREMENT,
  `P_Nom` varchar(200) NOT NULL,
  `P_Categorie` int(11) NOT NULL,
  `P_NbPlace` smallint(5) UNSIGNED NOT NULL,
  `P_Autheur` int(11) NOT NULL,
  `P_Description` text NOT NULL,
  `P_image` varchar(200) NOT NULL,
  `P_DateCrea` datetime NOT NULL,
  PRIMARY KEY (`ID_Projet`),
  KEY `P_Autheur` (`P_Autheur`),
  KEY `P_Autheur_2` (`P_Autheur`),
  KEY `P_Categorie` (`P_Categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `projet`
--

INSERT INTO `projet` (`ID_Projet`, `P_Nom`, `P_Categorie`, `P_NbPlace`, `P_Autheur`, `P_Description`, `P_image`, `P_DateCrea`) VALUES
(11, 'TeamFinder', 2, 5, 13, 'Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. Site internet pour gérer des projets. ', 'Informatique\r\njpg', '2019-01-15 14:42:05'),
(12, 'Jardin botanique', 1, 2, 12, 'Cum autem commodis intervallata temporibus convivia longa et noxia coeperint apparari vel distributio sollemnium sportularum, anxia deliberatione tractatur an exceptis his quibus vicissitudo debetur, peregrinum invitari conveniet, et si digesto plene consilio id placuerit fieri, is adhibetur qui pro domibus excubat aurigarum aut artem tesserariam profitetur aut secretiora quaedam se nosse confingit.\r\n\r\nHaec igitur Epicuri non probo, inquam. De cetero vellem equidem aut ipse doctrinis fuisset instructior est enim, quod tibi ita videri necesse est, non satis politus iis artibus, quas qui tenent, eruditi appellantur aut ne deterruisset alios a studiis. quamquam te quidem video minime esse deterritum.', 'Environnement\r\njpg', '2019-01-15 14:59:45'),
(13, 'New Windev', 17, 2, 13, 'Crée une nouvel version parce que les 3 autres sont de la merde !\r\nCrée une nouvel version parce que les 3 autres sont de la merde !\r\nCrée une nouvel version parce que les 3 autres sont de la merde !\r\nCrée une nouvel version parce que les 3 autres sont de la merde !\r\nCrée une nouvel version parce que les 3 autres sont de la merde !', 'Autresjpg', '2019-01-15 15:00:54'),
(16, 'Projet SAR', 2, 3, 14, 'Le projet est à réaliser par binôme.\r\nUn rapport de 2 à 3 pages maximum est à rendre par mail le 18/01/2019.\r\nL\'implémentation est à rendre par mail le mercredi 27/02/2019 au plus tard sous forme d\'un fichier Prenom-Nom.zip.\r\nUne soutenance sera programmée dans la semaine du 04/02/2019', 'Informatique\r\njpg', '2019-01-15 16:11:16'),
(17, 'Présentation anglais', 12, 3, 14, 'Présentation d\'anglais à faire à 2 sur la cyber securité pour le 16/01/2019. L\'oral doit durer une dizaine de minute minmum, en présence de maître Hillebrands aka Heisenberg, et des autres élèves bien relou.', 'Communication\r\njpg', '2019-01-15 16:18:31'),
(18, '<h1>Projet pourri</h1>', 5, 4, 13, 'ceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un testceci est un test', 'Jeux-vidéos\r\njpg', '2019-01-15 16:21:39'),
(19, 'Amour', 17, 3, 14, 'Cher collaborat.eur.rice, je fais appel à toi car je cherche la femme de sa vie à notre cher Francis, il n\'est pas très très beau mais il est gentil et attentionné. En effet, avec ses petites lunettes et sa barbichette il saura vous combler de part son intellectuel et sa connaissance du corps féminin...', 'Autresjpg', '2019-01-15 16:21:48'),
(20, 'IRC Online', 2, 3, 11, 'Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord Bonjour je voudrais faire une application comme discord ', 'Informatique\r\njpg', '2019-01-15 16:29:15'),
(21, 'Mappypute', 2, 2, 11, ' Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.Bonjour je voudrais réaliser un site de geolocalisation de prostitué en temps réel.', 'Informatique\r\njpg', '2019-01-15 16:31:47'),
(22, 'Une meuf pour Axel', 15, 2, 13, 'Homme recherche femme pour copuler une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille une fille', 'project22.jpg', '2019-01-15 16:32:24'),
(23, 'Troupe de cirque', 11, 11, 11, 'bonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirquebonjour je cherche des gens ayant un certains talent  pour monter une troupe de cirque', 'yfdzgz', '2019-01-15 16:33:29'),
(24, 'distrib Eau en afrique', 15, 4, 11, 'Bonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable couranteBonjour je voudrais faire une distribution de bouteille Contre x en Afrique pour les personne n\'ayant pas accès a l\'eau potable courante', 'Humanitaire\r\njpg', '2019-01-15 16:36:21'),
(25, 'Ressembler à Thomas', 12, 4, 14, 'Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. Il est trop beau. ', 'Communication\r\njpg', '2019-01-15 16:36:35'),
(26, 'Auto a energie positive', 8, 4, 11, 'Bonjour je voudrais créer une voiture électrique. pour la recharger il faudrait la posser ce qui rechargerai la batterie,ce qui permetterait d\'avoir 0 pollution hors création.Bonjour je voudrais créer une voiture électrique. pour la recharger il faudrait la posser ce qui rechargerai la batterie,ce qui permetterait d\'avoir 0 pollution hors création. Bonjour je voudrais créer une voiture électrique. pour la recharger il faudrait la posser ce qui rechargerai la batterie,ce qui permetterait d\'avoir 0 pollution hors création. Bonjour je voudrais créer une voiture électrique. pour la recharger il faudrait la posser ce qui rechargerai la batterie,ce qui permetterait d\'avoir 0 pollution hors création.', 'Automobile\r\njpg', '2019-01-15 16:46:29');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID_Utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `U_Nom` text NOT NULL,
  `U_Prenom` text NOT NULL,
  `U_Email` varchar(255) NOT NULL,
  `U_Mdp` varchar(255) NOT NULL,
  `U_DateNaissance` datetime NOT NULL,
  `U_Sexe` tinyint(1) NOT NULL,
  `U_Phone` varchar(15) NOT NULL,
  `U_Emploie` varchar(50) NOT NULL,
  `U_CP` varchar(5) DEFAULT NULL,
  `U_Ville` varchar(75) DEFAULT NULL,
  `U_Competence` text NOT NULL,
  `U_Bio` text NOT NULL,
  `U_DateInscrit` date NOT NULL,
  `U_DerniereCo` datetime DEFAULT NULL,
  `U_Token` varchar(25) DEFAULT NULL,
  `U_EmailConfirm` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID_Utilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID_Utilisateur`, `U_Nom`, `U_Prenom`, `U_Email`, `U_Mdp`, `U_DateNaissance`, `U_Sexe`, `U_Phone`, `U_Emploie`, `U_CP`, `U_Ville`, `U_Competence`, `U_Bio`, `U_DateInscrit`, `U_DerniereCo`, `U_Token`, `U_EmailConfirm`) VALUES
(11, 'Pexoto', 'Florian', 'flopex57@live.fr', '7186b89d21cdeba34bc75e4e238bbe75', '1998-08-22 00:00:00', 0, '0664003978', 'Developpeur BDD', NULL, NULL, 'STI2D ITEC\r\nBTS SNEC\r\nLP GL', 'Ceci est un test', '2019-01-15', '2019-01-15 14:41:17', '0', 1),
(12, 'PETROVIC', 'Thomas', 'petrovic.thomas@hotmail.com', '7186b89d21cdeba34bc75e4e238bbe75', '1999-06-25 00:00:00', 0, '0354756955', 'Informatien', NULL, NULL, 'BAC a sable\r\nBTS SNIR', 'Je suis Thomas\r\n, bonjour\r\nceci est un test', '2019-01-15', '2019-01-15 15:23:21', '0', 1),
(13, 'Recchia', 'François', 'recchiafrancois@gmail.com', '7583828054d2819870583c3af75fa0a5', '1998-11-27 00:00:00', 0, '0679089099', 'Développeur', NULL, NULL, 'Licence Genie Logiciel', 'Passionner d\'informatique', '2019-01-15', '2019-01-15 16:19:51', '0', 1),
(14, 'GENRAULT', 'Thibaut', 'thibaut.genrault@gmail.com', 'd5e0ebdf1ff102a7fbbce547619b5922', '1996-10-15 00:00:00', 0, '0643539599', 'Alternant', NULL, NULL, 'Bac +3 en cours', 'Etudiant à l\'IUT de Metz', '2019-01-15', NULL, '0', 1);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `Commentaire_ibfk_1` FOREIGN KEY (`COM_Autheur`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `Commentaire_ibfk_2` FOREIGN KEY (`COM_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `membre`
--
ALTER TABLE `membre`
  ADD CONSTRAINT `Membre_ibfk_1` FOREIGN KEY (`M_User`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `Membre_ibfk_2` FOREIGN KEY (`M_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `messageprive`
--
ALTER TABLE `messageprive`
  ADD CONSTRAINT `MessagePrive_ibfk_1` FOREIGN KEY (`MP_Author`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `MessagePrive_ibfk_2` FOREIGN KEY (`MP_Destinataire`) REFERENCES `utilisateur` (`ID_Utilisateur`);

--
-- Contraintes pour la table `piecejointe`
--
ALTER TABLE `piecejointe`
  ADD CONSTRAINT `PieceJointe_ibfk_1` FOREIGN KEY (`PJ_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `projet`
--
ALTER TABLE `projet`
  ADD CONSTRAINT `Projet_ibfk_1` FOREIGN KEY (`P_Autheur`) REFERENCES `utilisateur` (`ID_Utilisateur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
