<?php
require('fonctions.php');
$bdd = bdd_connect();
// VALIDATION DONNEE FORM
if(isset($_POST['email']) && $_POST['email'] != '' && preg_match("/\A([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+\z/", $_POST['email']) && isset($_POST['passwd']) && $_POST['passwd'] != '' && strlen($_POST['passwd']) >= 8) {
	// on test si l'utilisateur existe et que son adresse mail est confirmé
	$reqCo = $bdd->prepare('SELECT ID_Utilisateur, U_Nom, U_Prenom, U_EmailConfirm FROM utilisateur WHERE U_Email=? AND U_Mdp=?');
	$reqCo->execute(array($_POST['email'], crypt_mdp($_POST['passwd'])));
	$coExist = $reqCo->fetch();
	$reqCo->closeCursor();
	if($coExist != '') { // il existe dans la bdd
		if($coExist['U_EmailConfirm'] == '1') { // il a  confirmé son email
			$reqUpDateCo = $bdd->prepare('UPDATE utilisateur SET U_DerniereCo=NOW() WHERE ID_Utilisateur=?');
			$reqUpDateCo->execute(array($coExist['ID_Utilisateur']));
			$reqUpDateCo->closeCursor();
			session_start();
			$_SESSION['Id'] = htmlentities($coExist['ID_Utilisateur']);
			$_SESSION['Nom'] = htmlentities($coExist['U_Nom']);
			$_SESSION['Prenom'] = htmlentities($coExist['U_Prenom']);
			header('Location: '. $vue .'profil?user='.$coExist['ID_Utilisateur']);
		} else {
		header('Location: '. $vue .'connexion?result=27');
		}
	} else {
		header('Location: '. $vue .'connexion?result=8');
	}
} else {
		header('Location: '. $vue .'connexion?result=8');
}