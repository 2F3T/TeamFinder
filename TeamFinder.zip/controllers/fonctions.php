<?php
// objet connexion a MySQL
date_default_timezone_set('Europe/Paris');
////////////////////////////////////////////////
$host = '192.168.43.74';
$vue = 'http://'. $host .'/views/';
$ressource = 'http://'. $host .'/core/';
$control = 'http://'. $host .'/controllers/';
//$_SERVER['DOCUMENT_ROOT'];
////////////////////////////////////////////////
function bdd_connect()
{
	$dsn = 'mysql:dbname=teamfinder;host=localhost;charset=utf8;';
	$user = 'root';
	$password = '';
	try
	{
		$bdd = new PDO($dsn, $user, $password);
		$bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch (PDOException $e)
	{
		echo 'Échec lors de la connexion : ' . $e->getMessage();
	}
	return $bdd;
}

function errToMessage($errCode) {
	$monfichier = fopen('DbCodeError', 'r+');
	while(!feof($monfichier)) {
		$line = explode('|', fgets($monfichier));
		if($line[0] == $errCode)
			break;
	}
	fclose($monfichier);
	return $line[1];
}

function needConnect() {
	if(!isset($_SESSION['Id']))
		header('Location: '.$vue.'connexion');
}

function human_filesize($bytes)
{
    $bytes = floatval($bytes);
        $arBytes = array(
            0 => array(
                "UNIT" => "TO",
                "VALUE" => pow(1024, 4)
            ),
            1 => array(
                "UNIT" => "GO",
                "VALUE" => pow(1024, 3)
            ),
            2 => array(
                "UNIT" => "Mo",
                "VALUE" => pow(1024, 2)
            ),
            3 => array(
                "UNIT" => "Ko",
                "VALUE" => 1024
            ),
            4 => array(
                "UNIT" => "o",
                "VALUE" => 1
            ),
        );

    foreach($arBytes as $arItem)
    {
        if($bytes >= $arItem["VALUE"])
        {
            $result = $bytes / $arItem["VALUE"];
            $result = str_replace(".", "," , strval(round($result, 2)))." ".$arItem["UNIT"];
            break;
        }
    }
    return $result;
}

function strip_tags_content($text, $tags = '', $invert = FALSE) {

  preg_match_all('/<(.+?)[\s]*\/?[\s]*>/si', trim($tags), $tags);
  $tags = array_unique($tags[1]);
   
  if(is_array($tags) AND count($tags) > 0) {
    if($invert == FALSE) {
      return preg_replace('@<(?!(?:'. implode('|', $tags) .')\b)(\w+)\b.*?>.*?</\1>@si', '', $text);
    }
    else {
      return preg_replace('@<('. implode('|', $tags) .')\b.*?>.*?</\1>@si', '', $text);
    }
  }
  elseif($invert == FALSE) {
    return preg_replace('@<(\w+)\b.*?>.*?</\1>@si', '', $text);
  }
  return $text;
} 

function randAlphanum($random_string_length) {
	$characters = 'abcdefghijklmnopqrstuvwxyz0123456789;_|[]{}!-';
	$string = '';
	$max = strlen($characters) - 1;
	for ($i = 0; $i < $random_string_length; $i++) {
		$string .= $characters[mt_rand(0, $max)];
	}
	return $string;
}

function maxlen($value, $length = 50)// stop a certain caractére
{
	if (strlen($value) > $length)
	return substr($value , 0, 35 ) . '...' . substr($value , -15);
	else
	return $value;
}

function lien($url)//lien
{ 
	$in=array( '`((?:https?|ftp)://\S+[[:alnum:]]/?)`si', '`((?<!//)(www\.\S+[[:alnum:]]/?))`si'); 
	$out=array( '<strong><a href="$1" target="_blank" style=":hover{color: white;}">$1</a></strong>', '<strong><a href="http://$1" target="_blank" style=":hover{color: white;}">$1</a></strong>'); 
	return preg_replace($in,$out,$url); 
}

function is_url($uri){
    if(preg_match( '/^(http|https):\\/\\/[a-z0-9_]+([\\-\\.]{1}[a-z_0-9]+)*\\.[_a-z]{2,5}'.'((:[0-9]{1,5})?\\/.*)?$/i' ,$uri)){
      return $uri;
    }
    else{
        return false;
    }
}

function filter_filename($name) {
	$name = str_replace(' ', '', $name);
	$name = str_replace(array_merge(
		array_map('chr', range(0, 31)),
		array('<', '>', ':', '"', '/', '\\', '|', '?', '*')
	), '', $name);
	// maximise filename length to 255 bytes http://serverfault.com/a/9548/44086
	$ext = pathinfo($name, PATHINFO_EXTENSION);
	$name= mb_strcut(pathinfo($name, PATHINFO_FILENAME), 0, 255 - ($ext ? strlen($ext) + 1 : 0), mb_detect_encoding($name)) . ($ext ? '.' . $ext : '');
	return $name;
}

function downloadUrlToFile($url, $outFileName) {   
    if(is_file($url)) {
        copy($url, $outFileName); 
    } else {
        $options = array(
          CURLOPT_FILE    => fopen($outFileName, 'w'),
          CURLOPT_TIMEOUT =>  28800, // set this to 8 hours so we dont timeout on big files
          CURLOPT_URL     => $url
        );

        $ch = curl_init();
        curl_setopt_array($ch, $options);
        curl_exec($ch);
        curl_close($ch);
    }
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function salut()//salut
{
	$heure = date("H");
	$bdd = bdd_connect();
	$query = $bdd->prepare("SELECT pseudo FROM membre WHERE pseudo = ?");
	$query -> execute(array($_SESSION['pseudo']));
	$reponse = $query -> fetch();
	$pseudo = $reponse['pseudo'];
	if ($heure >= 6 && $heure <= 18)
	{
		return 'Salut '. htmlspecialchars($pseudo) .'' ;
	}
	elseif($heure >= 18 && $heure <= 23)
	{
		return 'Bonsoir '. htmlspecialchars($pseudo) .'' ;
	}
	else
	{
		return 'Bonne nuit '. htmlspecialchars($pseudo) .'' ;
	}
}


function crypt_mdp($mdp_a_crypte)//crypt mdp
{
	$mdp = $mdp_a_crypte;
	for ($i=0;$i<65535;$i++)
	{ 
		$mdp = sha1($mdp);
		$mdp = md5($mdp);
	}
	return $mdp;
}


function mobile()// mobile ?
{
	if (
	strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPod') || strstr($_SERVER['HTTP_USER_AGENT'],'android') || 
	strstr($_SERVER['HTTP_USER_AGENT'],'blackberry') || strstr($_SERVER['HTTP_USER_AGENT'],'Windows Phone') || strstr($_SERVER['HTTP_USER_AGENT'],'symbian') || 
	strstr($_SERVER['HTTP_USER_AGENT'],'series60') || strstr($_SERVER['HTTP_USER_AGENT'],'palm') || strstr($_SERVER['HTTP_USER_AGENT'],'KitKat')
	)
	{
		return true;
	}
	else
	{
		return false;
	}
}


function sent_mail($pseudo,$adresse_mail,$sujet,$message,$message_sans_html)// sent mail
{
	require("class.phpmailer.php");
	$mail = new PHPmailer();
	$mail->IsSMTP();
	$mail->SMTPAuth = true;
	$mail->SMTPSecure = "tls";
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587;
	$mail->Username = "gestiondeprojet2f3t@gmail.com";
	$mail->Password = "2F3T2F3T";
	$email = $adresse_mail;
	$name= $pseudo;
	$mail->AddAddress($adresse_mail ,$pseudo);
	$mail->From = "gestiondeprojet2f3t@gmail.com";
	$mail->FromName = "TeamFinder";
	$mail->AddReplyTo("gestiondeprojet2f3t@gmail.com","TeamFinder");
	$mail->IsHTML(true);
	$mail->Subject = $sujet;
	$mail->Body = $message;
	$mail->AltBody = $message_sans_html;
	if(!$mail->Send())
	{
		return false;
	}
	else
	{
		return true;
	}
}
?>