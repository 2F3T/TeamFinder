<?php
$bdd = bdd_connect();
include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-listCateg.php'); 
if(isset($_GET['categ']) && $_GET['categ'] != '') {
	$reqProjets = $bdd->prepare('SELECT ID_Projet,P_Nom,P_Categorie,P_NbPlace,P_Description,P_image,P_DateCrea,U_Nom,U_Prenom FROM projet JOIN utilisateur ON P_Autheur=ID_Utilisateur WHERE P_Categorie=?');
	$reqProjets->execute(array($_GET['categ']));
} else {
	$reqProjets = $bdd->query('SELECT ID_Projet,P_Nom,P_Categorie,P_NbPlace,P_Description,P_image,P_DateCrea,U_Nom,U_Prenom FROM projet JOIN utilisateur ON P_Autheur=ID_Utilisateur');
}
if($reqProjets == '') {
	header('Location: '. $vue .'listeproject');
}
?>