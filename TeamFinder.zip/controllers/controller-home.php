<?php
$bdd = bdd_connect();

$reqProjets = $bdd->prepare('SELECT ID_Projet, P_Nom,P_image,P_Categorie,P_NbPlace,utilisateur.U_Nom,utilisateur.U_Prenom FROM projet JOIN utilisateur ON projet.P_Autheur=utilisateur.ID_Utilisateur ORDER BY projet.P_DateCrea DESC LIMIT 5');
$reqProjets->execute();

?>