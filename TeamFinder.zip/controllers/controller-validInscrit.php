<?php
require('fonctions.php');
$bdd = bdd_connect();
// VALIDATION DONNEE FORM
if(isset($_GET['token']) && strlen($_GET['token']) == 25) {
	$reqToken = $bdd->prepare('SELECT ID_Utilisateur, U_Nom, U_Prenom FROM utilisateur WHERE U_Token=?');
	$reqToken->execute(array($_GET['token']));
	$tokenExist = $reqToken->fetch();
	$reqToken->closeCursor();
	if($tokenExist != '') {
		// token valide
		$reqValidUser = $bdd->prepare('UPDATE utilisateur SET U_Token=0, U_EmailConfirm=1 WHERE ID_Utilisateur=?');
		$reqValidUser->execute(array($tokenExist['ID_Utilisateur']));
		$reqValidUser->closeCursor();
		session_start();
    $_SESSION['Id'] = $tokenExist['ID_Utilisateur'];
    $_SESSION['Nom'] = htmlentities($tokenExist['U_Nom']);
	$_SESSION['Prenom'] = htmlentities($tokenExist['U_Prenom']);
    header('Location: '.$vue.'profil.php');
	} else {
		header('Location: '.$vue.'validationUser.php?token='. $_GET['token'] .'&result=7');
	}
}
?>