<?php
require('fonctions.php');
session_start();
$bdd = bdd_connect();
$reqLastIdProjet = $bdd->query('SELECT max(ID_Projet) AS idProjet FROM projet');
$lastIdProjet = $reqLastIdProjet->fetch();
$reqLastIdProjet->closeCursor();
$codes='';
$photo='';
// VALIDATION DONNEE FORM
needConnect();
if(!isset($_POST['titre']) || strlen($_POST['titre']) > 25) {
	$codes = $codes.'28|';
}
if(!isset($_POST['descri']) || strlen($_POST['descri']) < 100 ){
	$codes = $codes.'29|';
}
if(!isset($_POST['categ'])){
	$codes = $codes.'32|';
}
if(!isset($_POST['nbRecherche']) && !isset($_POST['nbDeja'])){
	$codes = $codes.'31|';
} else {
	if(($_POST['nbRecherche']+$_POST['nbDeja']) == 0)
		$codes = $codes.'30|';
}
// ---------- PHOTO VALIDATOR ---------
if(isset($_FILES['photo']) && $_FILES['photo']['tmp_name'] != '') {
	$dossier = $_SERVER['DOCUMENT_ROOT'].'/core/img/user/';
	$fichier = basename($_FILES['photo']['name']);
	$taille_maxi = 200000;
	$taille = filesize($_FILES['photo']['tmp_name']);
	$extensions = array('.png', '.gif', '.jpg', '.jpeg');
	$extension = strrchr($_FILES['photo']['name'], '.');
	if(!in_array($extension, $extensions)) { //Si l'extension n'est pas dans le tableau
		$codes = $codes.'15|';
		$erreur = true;
	}
	if($taille>$taille_maxi) {
		$codes = $codes.'16|';
		$erreur = true;
	}
	if(!isset($erreur)) { //S'il n'y a pas d'erreur, on upload
		//On formate le nom du fichier ici...
		echo 'trs';
		$photo = $dossier.'projet'.($lastIdProjet['idProjet']+1).strrchr($_FILES['photo']['name']);
		echo '.'.$photo;
		if(move_uploaded_file($_FILES['photo']['tmp_name'], $photo, '.')) { //Si la fonction renvoie TRUE, c'est que ça a fonctionné...
			$photo = 'projet'.$lastIdProjet['idProjet'].strrchr($_FILES['photo']['name'], '.');
			echo $photo;
		} else {//Sinon (la fonction renvoie FALSE).
			$codes = $codes.'17|';
		}
	}
} else {
	if(isset($_POST['categ'])) {
		$reqCategorie = $bdd->prepare('SELECT ID_Categorie, CAT_Nom FROM categorie WHERE ID_Categorie=?');
		$reqCategorie->execute(array($_POST['categ']));
		$donnee = $reqCategorie->fetch();
		$photo = $donnee['CAT_Nom'].'jpg';
	}
}
if($codes != '') {
	if(substr($codes, -1) == '|')
		$codes = substr($string, 0, -1);
	header('Location: '. $vue .'projectcreate?result='.$codes.'');
	exit;
}
$reqAddProjet = $bdd->prepare('
INSERT INTO projet(P_Nom, P_Categorie, P_NbPlace, P_Autheur, P_Description, P_image, P_DateCrea) 
VALUES(:nom, :categ, :nbPlace, :autheur, :descri, :image, NOW())');
$reqAddProjet->execute(array(
	"nom" => $_POST['titre'], 
	"categ" => $_POST['categ'], 
	"nbPlace" => $_POST['nbRecherche']+$_POST['nbDeja']+1, //+1 parce que le fondateur est forcément membre 
	"autheur" => $_SESSION['Id'], 
	"descri" => $_POST['descri'], 
	"image" => $photo
));
header('Location: '.$vue.'projectcreate?result=254');
?>