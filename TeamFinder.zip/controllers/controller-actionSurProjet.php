<?php
require('fonctions.php');
session_start();
$bdd = bdd_connect();
needConnect();
if(isset($_POST['supp'])) {
	
	// verifie si personne sur la page est le fondateur du projet
	$reqProjets = $bdd->prepare('SELECT ID_Projet, P_Autheur FROM projet JOIN utilisateur ON P_Autheur=ID_Utilisateur WHERE ID_Projet=?');
	$reqProjets->execute(array($_POST['proj']));
	$ProjetDroit = $reqProjets->fetch();
	$reqProjets->closeCursor();
	if($_SESSION['Id'] == $ProjetDroit['P_Autheur']) {
		// membre
		$reqDelProj = $bdd->prepare('DELETE FROM membre WHERE M_Projet=?');
		$reqDelProj->execute(array($_POST['proj']));
		$reqDelProj->closeCursor();
		// projet
		$reqDelProj = $bdd->prepare('DELETE FROM projet WHERE ID_Projet=?');
		$reqDelProj->execute(array($_POST['proj']));
		$reqDelProj->closeCursor();
		header('Location: '.$vue.'profil');
	} else {
		header('Location: '.$vue.'connexion');
	}
} else if(isset($_POST['mod'])) {
	// envoie vers la page de création d'un projet avec comme paramètre le projet ett les champs pré rempli
} else if(isset($_POST['post'])) {
	// ajoute le membre ayant postuler dans la table membre avec M_Attente à 1 
	$reqMembrePostul = $bdd->prepare('INSERT INTO membre(M_User, M_Projet, M_Attente) VALUES (?, ?, 1)');
	$reqMembrePostul->execute(array($_SESSION['Id'], $_POST['proj']));
	$reqMembrePostul->closeCursor();
	// obtenir le nom du fondateur$reqProjets = $bdd->prepare('SELECT ID_Projet, P_Autheur FROM projet JOIN utilisateur ON P_Autheur=ID_Utilisateur WHERE ID_Projet=?');
	$reqnomFondateur = $bdd->prepare('SELECT U_Nom,U_Prenom,U_Email, P_Nom FROM Projet JOIN utilisateur ON utilisateur.ID_Utilisateur = projet.P_Autheur WHERE ID_Projet=?');
	$reqnomFondateur->execute(array($_POST['proj']));
	$nomFondateur = $reqnomFondateur->fetch();
	$reqnomFondateur->closeCursor();
	// envoie mail au fondateur du projet avec un lien vers la page de décision d'acceptation
	$message = 'TeamFinder,<br><br>Vous avez reçu une candidature sur le projet : '.$nomFondateur['P_Nom'].'<br>Vous pouvez valider ou refuser cette candidature en étudiant la candidature.<br><br><a href="'.$vue.'validerRefuser?idproj='.$_POST['proj'].'&iduser='.$_SESSION['Id'].'">Etudier la candidature</a>';
	$message_sans_html = $vue.'validerRefuser?idproj='.$_POST['proj'].'&iduser='.$_SESSION['Id'];
	sent_mail($nomFondateur['U_Nom'].$nomFondateur['U_Prenom'], $nomFondateur['U_Email'], 'Candidature sur '.$nomFondateur['P_Nom'],$message,$message_sans_html);
	// confirmUser.php?idProj=&idUser=
	header('Location: '.$vue.'project?proj='.$_POST['proj'].'');
} else {
	header('Location: '.$vue.'home');
}
?>