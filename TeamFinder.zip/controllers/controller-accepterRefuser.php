<?php
require('fonctions.php');
$bdd = bdd_connect();
session_start();
needConnect();
if(isset($_POST['iduser']) && isset($_POST['idproj'])) {
	$reqFondateur = $bdd->prepare('SELECT P_Autheur FROM projet WHERE ID_Projet=?');
	$reqFondateur->execute(array($_POST['idproj']));
	$fondateur = $reqFondateur->fetch();
	$reqFondateur->closeCursor();
	if($_SESSION['Id'] == $fondateur['P_Autheur']) {
		// c'est le fondateur qui est co on continue
		$reqCandidat = $bdd->prepare('SELECT M_Projet, U_Email, P_Nom FROM membre JOIN utilisateur ON ID_Utilisateur=M_User JOIN projet ON ID_Projet=M_Projet WHERE M_User=?');
		$reqCandidat->execute(array($_POST['iduser']));
		$candidat = $reqCandidat->fetch();
		if($candidat['M_Projet'] !=  '') {
			if(isset($_POST['accepter'])) {
				// on peut accepter le membre modifier le boolean
				$reqvalide = $bdd->prepare('UPDATE membre SET M_Attente=0 WHERE M_User=? AND M_Projet=?');
				$reqvalide->execute(array($_POST['iduser'], $_POST['idproj']));
				//on peut envoye un mail pour indiquer à l'utilisateur qu'il a été accepter
				$message = 'Nous avons plaisir de vous annoncer que votre candidature sur le projet '.$candidat['P_Nom'].' a été accepter !';
				$message_sans_html = $message;
				sent_mail($_SESSION['Nom'].' '.$_SESSION['Prenom'], $candidat['U_Email'], 'Rejet de candidature sur '.$candidat['P_Nom'],$message,$message_sans_html);
				header('Location: '. $vue .'project?proj='.$_POST['idproj']);
			} else if(isset($_POST['refuser'])) {
				//on peut envoye un mail pour indiquer à l'utilisateur qu'il a été refusé
				$message = 'Nous avons le regret de vous annoncer que votre candidature sur le projet '.$candidat['P_Nom'].' a été refuser !';
				$message_sans_html = $message;
				sent_mail($_SESSION['Nom'].' '.$_SESSION['Prenom'], $candidat['U_Email'], 'Rejet de candidature sur '.$candidat['P_Nom'],$message,$message_sans_html);
				header('Location: '. $vue .'project?proj='.$_POST['idproj']);
			}
		} else {
			header('Location: '. $vue .'home');
		}
	} else {
		header('Location: '. $vue .'connexion');
	}
} else {
	header('Location: '. $vue .'home');
}
?>