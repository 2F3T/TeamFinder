<?php
$bdd = bdd_connect();
// si pas connecter go sur page de connexion
needConnect();

if(isset($_GET['proj'])) {
	$reqProjets = $bdd->prepare('SELECT  ID_Projet,P_Nom,P_Categorie,P_NbPlace,P_Description,P_image,P_DateCrea,U_Nom,U_Prenom, P_Autheur FROM projet JOIN utilisateur ON projet.P_Autheur=utilisateur.ID_Utilisateur WHERE ID_Projet=?');
	$reqProjets->execute(array($_GET['proj']));
	$ProjetsExist = $reqProjets->fetch();
	$reqProjets->closeCursor();
	
	$reqMembres = $bdd->prepare('SELECT U_Nom, U_Prenom, U_Emploie, ID_Utilisateur FROM membre INNER JOIN utilisateur ON ID_Utilisateur = M_User WHERE M_Projet=? AND M_Attente=0');
	$reqMembres->execute(array($_GET['proj']));
	
	$reqComm = $bdd->prepare('SELECT U_Nom,U_Prenom,COM_Msg,COM_Date,ID_Com FROM commentaire JOIN utilisateur ON commentaire.COM_Autheur = utilisateur.ID_Utilisateur WHERE COM_Projet=?');
	$reqComm->execute(array($_GET['proj']));
	
	$reqCommReponse = $bdd->prepare('SELECT U_Nom,U_Prenom,CR_Msg,CR_Date,ID_Com FROM commentairereponse JOIN utilisateur ON commentairereponse.CR_Autheur = utilisateur.ID_Utilisateur WHERE CR_Projet=?');
	$reqCommReponse->execute(array($_GET['proj']));
	
	$reqPieceJoin = $bdd->prepare('SELECT PJ_Fichier, PJ_Date FROM piecejointe WHERE PJ_Projet=?');
	$reqPieceJoin->execute(array($_GET['proj']));
	
	$reqDejaPostule = $bdd->prepare('SELECT M_User FROM membre WHERE M_Projet=?');
	$reqDejaPostule->execute(array($_GET['proj']));
	
	if($ProjetsExist == '') {
		header('Location: '. $vue .'listeproject');
	}
} else {
	header('Location: '. $vue .'listeproject');
}
?>