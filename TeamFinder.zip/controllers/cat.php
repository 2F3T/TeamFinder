<?php
require('fonctions.php');
$genToken = "";
$message = '<a href="'.$vue.'validationUser.php?token='.$genToken.'"><validation email</a>';
$message_sans_html = $vue.'validationUser.php?token='.$genToken.'';
sent_mail("nom","petrovic.thomas@hotmail.com",'Validation email sur TeamFinder',$message,$message_sans_html);
/*$monfichier = fopen('categ.txt', 'r+');
	while(!feof($monfichier)) {
		$reqAddUser = $bdd->prepare(
		'INSERT INTO categorie(CAT_Nom) 
		VALUES(:libel)'
		);
		$reqAddUser->execute(array(
			"libel" => fgets($monfichier)
		));
		$reqAddUser->closeCursor();
	}
	fclose($monfichier);*/
?>