<?php
$bdd = bdd_connect();
$reqCategorie = $bdd->query('SELECT ID_Categorie, CAT_Nom FROM categorie');
?>