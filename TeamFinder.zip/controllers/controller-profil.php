<?php
$bdd = bdd_connect();
needConnect();
if(isset($_GET['user'])) {
	$reqProjets = $bdd->prepare('SELECT * FROM utilisateur WHERE ID_Utilisateur=?');
	$reqProjets->execute(array($_GET['user']));
	$ProjetsExist = $reqProjets->fetch();
	$reqProjets->closeCursor();
	
	if($ProjetsExist == '') {
		header('Location: '. $vue .'Home');
	}
} else {
	header('Location: '. $vue .'profil?user='.$_SESSION['Id']);
}
?>