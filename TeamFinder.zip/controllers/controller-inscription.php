<?php
require('fonctions.php');
$bdd = bdd_connect();
// VALIDATION DONNEE FORM
$codes='';
$nom='';
if(!isset($_POST['civilite']) || $_POST['civilite'] == '') {
	$codes = $codes.'22|';
}
if(strlen($_POST['nom']) < 3 && strlen($_POST['nom']) > 25 && !preg_match("/\A[a-zA-Z_]{3,25}\z/", $_POST['nom'])){
	$codes = $codes.'9|';
}
if(strlen($_POST['prenom']) < 3 && strlen($_POST['prenom']) > 25 && !preg_match("/\A[a-zA-Z_]{3,25}\z/", $_POST['prenom'])){
	$codes = $codes.'10|';
}
if(!preg_match('#^([0-9]{2})([/-])([0-9]{2})\2([0-9]{4})$#', $_POST['dateNais'], $m) != 1 && !checkdate($m[3], $m[1], $m[4])) {
	// date naissance format invalide
	$codes = $codes.'22|';
}
if(!preg_match('/^0[1-689][0-9]{8}$/', $_POST['telephone'])){
	// telephone invalide
	$codes = $codes.'11|';
}

if($_POST['emploi'] == '' || !isset($_POST['emploi'])){
	// emploi invalide
	$codes = $codes.'24|';
}

if($_POST['bio'] == '' || !isset($_POST['bio'])){
	// bio invalide
	$codes = $codes.'25|';
}

if($_POST['competence'] == '' || !isset($_POST['competence'])){
	// competence invalide
	$codes = $codes.'26|';
}

$reqPseudo = $bdd->prepare('SELECT ID_Utilisateur FROM Utilisateur WHERE U_Nom=? AND U_Prenom=?');
$reqPseudo->execute(array($_POST['nom'], $_POST['prenom']));
$pseudoExist = $reqPseudo->fetch();
$reqPseudo->closeCursor();
if($pseudoExist != '') {
	//echo 'PHP say : pseudo pris';
	$codes = $codes.'1|';
}
if(isset($_POST['email']) && $_POST['email'] != '' && preg_match("/\A([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+\z/", $_POST['email'])) {
	$reqEmail = $bdd->prepare('SELECT ID_Utilisateur FROM Utilisateur WHERE U_Email=?');
	$reqEmail->execute(array($_POST['email']));
	$emailExist = $reqEmail->fetch();
	$reqEmail->closeCursor();
	if($emailExist != '') {
		//echo 'PHP say : mail pris';
		$codes = $codes.'6';
	}
	if(isset($_POST['passwd']) && $_POST['passwd'] != '' && strlen($_POST['passwd']) >= 8) {
		if(isset($_POST['passwd2']) && $_POST['passwd2'] == $_POST['passwd']) {
			if($codes != '') {
				if(substr($codes, -1) == '|')
					$codes = substr($string, 0, -1);
				header('Location: '. $vue .'inscription?result='.$codes.'');
				exit;
			}
			if($codes == '1|') {
				$timestamp = strtotime($_POST['dateNais']);
				$day = date('D', $timestamp);
				$nom = $day.$_POST['nom'];
			} else {
				$nom = $_POST['nom'];
			}
			$genToken = randAlphanum(25);
			echo $genToken;
			// send email
			// avec comme link : $vue.validationUser?token=$genToken
			$reqAddUser = $bdd->prepare(
			'INSERT INTO utilisateur(U_Sexe, U_Emploie, U_Nom, U_Prenom, U_DateNaissance, U_Phone, U_Competence, U_Bio, U_Email, U_Mdp, U_Token, U_EmailConfirm, U_DateInscrit) 
			VALUES(:civil, :emploie, :nom, :prenom, :dn, :tel, :competence, :bio, :email, :mdp, :token, 0, NOW())'
			);
			$reqAddUser->execute(array(
				"emploie" => $_POST['emploi'], 
				"civil" => $_POST['civilite'], 
				"nom" => $nom, 
				"prenom" => $_POST['prenom'], 
				"dn" => $_POST['dateNais'], 
				"email" => $_POST['email'], 
				"mdp" => crypt_mdp($_POST['passwd']), 
				"token" => $genToken, 
				"tel" => $_POST['telephone'],
				"bio" => $_POST['bio'],
				"competence" => $_POST['competence']
			));
			//echo 'PHP say : succes aller voir vos mails';
			$message = 'TeamFinder,<br><br>Vous venez de crée un compte sur le site TeamFinder.<br>Merci de bien vouloir confirmer votre adresse mail en cliquant sur le lien suivant : <br><a href="'.$vue.'validationUser?token='.$genToken.'">validation email</a>';
			$message_sans_html = $vue.'validationUser?token='.$genToken;
			sent_mail($nom.$_POST['prenom'],$_POST['email'],'Validation email sur TeamFinder',$message,$message_sans_html);
			header('Location: '.$vue.'inscription?result=251');
			// success aller voir vos mail
		} else {
			//echo 'PHP say : confirm mdp non';
			header('Location: '.$vue.'inscription?result=21');
			// confirmation mdp incorrect
		}
	} else {
		//echo 'PHP say : mdp incorrect';
		header('Location: '.$vue.'inscription?result=3');
		// mot de passe incorrect
	}
} else {
	//echo 'PHP say : email incorrect';
	header('Location: '.$vue.'inscription?result=4');
	// email non valide
}
?>