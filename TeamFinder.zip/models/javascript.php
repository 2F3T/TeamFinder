<script <?php echo 'src='.$ressource.'/js/jquery.js'?>></script>
<script <?php echo 'src='.$ressource.'js/bootstrap.min.js'?>></script>