<form class="my-5 mx-5" method="post" <?php echo 'action="'.$control.'controller-projectcreate.php"'; ?> >
  <div id="ligne2" class="row">
    <div id="espace" class="col-1 "></div>
    <div id="espace" class="col-11 "><h1>Informations sur le projet</h1></div>
  </div>
  <div id="ligne3" class="row">
    <div id="espace" class="col-1"></div>

    <!-- ### TITRE DU PROJET ### -->
      <div class="form-group col-3">
        <label for="Titre">Titre</label>
        <input id="Titre" type="text" name="titre" class="form-control" maxlength="25" placeholder="Entrez un titre ...">
      </div>


    <!-- ### DESCRIPTION DU PROJET ### -->
      <div class="form-group col-4">
        <label for="Description">Description</label>
        <textarea id="Description" class="form-control" name="descri" minlength="200" placeholder="Entrez la description du projet ..."></textarea>
      </div>



    <!-- ### PHOTO DU PROJET ### -->
    <div class="form-group col-3">
      <label for="PhotoProjet">Photo du projet</label>
      <div class="custom-file">
        <input type="file" class="custom-file-input" name="photo" id="PhotoProjet">
		<input type="hidden" name="MAX_FILE_SIZE" value="200000" />
        <label class="custom-file-label" for="photo">Télécharger une image ...</label>
      </div>
    </div>
    <div id="espace" class="col-1"></div>
  </div>


  <div id="ligne4" class="row">
    <div id="espace" class="col-1 "></div>
    <div id="espace" class="col-11 "><h1>Membres</h1></div>
  </div>

  <div id="ligne5" class="row">
    <div id="espace" class="col-1 "></div>
    <!-- ### NOMBRE DE PERSONNES RECHERCHEES ### -->
    <div id="MembreRecherche" class="col-3">
      <label>Nombre de personnes recherchées</label>
      <select id="SelectMR" name="nbRecherche" class="custom-select" onchange="ChangerNombreMembresRecherche()" required>
        <option value="0" selected>0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select>
    </div>

    <div id="espace" class="col-4"></div>

    <!-- ### NOMBRES DE PERSONNES QUI ONT DEJA REJOINT LE PROJET ### -->
    <div id="MembreRecherche" class="col-3">
      <label>Nombre de personnes ayant déjà rejoint le projet</label>
      <select id="SelectMP" name="nbDeja" class="custom-select" onchange="ChangerNombreMembresPresents()" required>
        <option value="0" selected>0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
        <option value="8">8</option>
        <option value="9">9</option>
        <option value="10">10</option>
      </select>
    </div>

    <div id="espace" class="col-1"></div>
  </div>

  <div id="ligne6" class="row">

    <div id="espace" class="col-1"></div>

    <!-- ### MEMBRES RECHERCHES ### -->
    <div class="col-4">
      <label>Membres Recherchés</label>
      <div id="MembresRecherches">
      </div>
    </div>


    <div id="espace" class="col-3"></div>

    <!-- ### MEMBRES DEJÀ PRESENTS ### -->
    <div class="col-3">
      <label>Membres déjà présents</label>
      <div id="MembresPresents">
      </div>
    </div>

    <div id="espace" class="col-1"></div>

  </div>
  
  <div id="ligne7" class="row">
	<div id="espace" class="col-3"></div>
		<div id="Filtre" class="col-6 input-group">
		<label for="categ">Catégorie</label>
		<div class="input-group">
			<select class="custom-select" name="categ" id="categ">
				<?php
				include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-listCateg.php');
				while($categ = $reqCategorie->fetch()) {
					echo '<option value="'.$categ['ID_Categorie'].'">'.$categ['CAT_Nom'].'</option>';
				}
				$reqCategorie->closeCursor();
				?>
			</select>
		</div>
	  </div>
	  <div id="espace" class="col-3"></div>
	</div>


  <div id="ligne8" class="row">
    <div id="espace" class="col-5"></div>
    <div class="col-2">
      <input id="BoutonEnvoyer" class="btn btn-primary mx-auto" type="submit" value="Créer le projet"/>
    </div>
    <div id="espace" class="col-5"></div>
  </div>
  <?php if(isset($_GET['result'])) { include('resultForm.php'); } ?>
</form>