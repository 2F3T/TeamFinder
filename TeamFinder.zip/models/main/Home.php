<div class="accroche">
            <center>
                <h1 id="bvn">
                    Bienvenue sur le site TeamFinder!
                    Nous esperons que grâce à notre site, vous pourrez apporter votre expertise
                    à des milliers de collaborateurs à travers le monde!<br>
                </h1>
                <a class="btn btn-primary btn-lg active" role="button" href="/views/listeproject" aria-pressed="true"> Commencer </a>
            </center>
        </div>
        <div class="separer">
            <h1 id="projet"> Projets récents </h1>
        </div>
		<br>
		
		<div id="main" class="mx-5">
			<div id="ligne2" class="row mx-2">

				<?php
				require ROOT.'project_miniature.php'
				?>
			</div>
		</div>