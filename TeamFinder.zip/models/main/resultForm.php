<?php
if(strpos($_GET['result'], '|') !== false) {
 	$errorsCode = explode('|', $_GET['result']);
	print(($errorsCode[0] <= 250) ? '<div class="alert alert-danger"><ul>' : '<div class="alert alert-success"><ul>');
			foreach($errorsCode as $errCode) {
			  print('<li>'.errToMessage($errCode).'</li>');
			}
	print('</ul></div>');
} else {
?>
	<div <?php print(($_GET['result'] <= 250) ? 'class="alert alert-danger"' : 'class="alert alert-success"'); ?>>
		<ul>
		  <li><?php print(errToMessage($_GET['result'])); ?></li>
		</ul>
	</div>
<?php
}
?>