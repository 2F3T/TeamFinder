<!-- ### HEADER ### -->
<div id="header" class="row mx-auto">

  <!-- ### PHOTO DE PROFIL ### -->
  <div class="col-3 valign">
	  <?php
		include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-profil.php');
		$filename = $_SERVER['DOCUMENT_ROOT'].'/core/img/user/image'.$ProjetsExist['ID_Utilisateur'];
		if (file_exists($filename)) {
			?>
			<img id="PhotoProfil" <?php echo 'src="'.$ressource.'img/user/image'.$ProjetsExist['ID_Utilisateur'].'"'?> class="mx-auto"  alt="Photo de Profil"  height="150" width="150"/>
			<?php
		}	
		else{
			?>
			<img id="PhotoProfil" <?php echo 'src="'.$ressource.'img/user/image0.jpg"'?> class="mx-auto"  alt="Photo de Profil"  height="150" width="150"/>
			<?php
		}
		?>
   </div>

  <!-- ### NOM | PRENOM ### -->
  <div class="col-2" style=" display:block; align-items:center;">
    <br>
    <span id="Nom"><?php echo $ProjetsExist['U_Nom']; ?></span> <br>
    <span id="Prenom"><?php echo $ProjetsExist['U_Prenom']; ?></span>
	<br>
	<a href="profilmodif.php" id="ModifierProfil" role="button" class="btn btn-primary">Modifier profil</a>
  </div>


  <!-- ### BIOGRAPHIE ### -->
  <div id="Biographie" class="col-7">
    <p>
      <b>Biographie :</b>
		<span class="font-weight-light font-italic">
        <?php echo $ProjetsExist['U_Bio']; ?>
		</span>
    </p>
  </div>

</div>

<!-- ### PARTIE CENTRALE ### -->
<div id="main" class="row mx-auto">

  <div class="col-1"></div>

  <!-- ### PARCOURS PROFESSIONNEL & ETUDES (GAUCHE) ### -->
  <div id="Experience" class="col-4">
    <ul class="list-group">
      <li class="list-group-item">Experiences professionnelles<br>
		<ul>
			<li>
				<?php
					echo $ProjetsExist['U_Emploie'];
				?>
			</li>
		</ul>
	  </li>
      <li class="list-group-item">Diplômes<br>
	  	<ul>
			<li>
				<?php
					echo $ProjetsExist['U_Competence'];
				?>
			</li>
		</ul>
	  </li>
    </ul>
  </div>

  <div class="col-1"></div>

  <!-- ### PROJETS EN COURS ET REALISES (DROITE) ### -->
  <div id="Projets" class="col-6">

    <!-- ### PROJETS EN COURS  ### -->
    <ul class="list-group">
      <details>
        <summary>Projets en cours</summary>
        <div class="card-group">
          <div class="card col-3">
            <img class="card-img-top" src="../core/img/user/default.jpg" alt"Image du projet">
            <div class="card-body">
              <p class="card-text">Titre du projet</p>
            </div>
          </div>
          <div class="card  col-3">
            <img class="card-img-top" src="../core/img/user/default.jpg" alt"Image du projet">
            <div class="card-body">
              <p class="card-text">Titre du projet</p>
            </div>
          </div>
        </div>
      </details>
    </ul>

    <!-- ### PROJETS REALISES  ### -->

    <ul class="list-group">
      <details>
        <summary>Projets terminés</summary>
        <div class="card col-3">
          <img class="card-img-top" src="../core/img/user/default.jpg" alt"Image du projet">
          <div class="card-body">
            <p class="card-text">Titre du projet</p>
          </div>
        </div>

      </details>
    </ul>
  </div>

</div>