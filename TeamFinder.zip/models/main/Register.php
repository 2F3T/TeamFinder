<center>
	<div class="connexion">
		<h1 id="connexion"> Inscription </h1>
	</div>
</center>
<form <?php echo 'action="'. $control .'controller-inscription.php"'; ?> method="post">
	<div class="civilite">
		<!-- Material inline 1 -->
		<div> Civilité </div>
		<div class="form-check form-check-inline">
			<input type="radio" value="0" class="form-check-input" id="materialInline1" name="civilite">
			<label class="form-check-label" for="materialInline1"> Homme </label>
		</div>
		<!-- Material inline 2 -->
		<div class="form-check form-check-inline">
			<input type="radio" value="1" class="form-check-input" id="materialInline2" name="civilite">
			<label class="form-check-label" for="materialInline2"> Femme </label>
		</div>
		<!-- Material inline 3 -->
		<div class="form-check form-check-inline">
			<input type="radio" class="form-check-input" id="materialInline3" name="civilite">
			<label class="form-check-label" for="materialInline3"> Autre </label>
		</div>
	</div>
	<!-- Nom, prénom & Email -->
	<div class="ligne1">
		<div class="form-group green-border-focus" id="div1_1">
			<label for="exampleFormControlTextarea5"> Nom </label>
			<input type="text" class="form-control" id="exampleFormControlTextarea6" rows="3" name="nom" required />
		</div>
		<div class="form-group green-border-focus" id="div1_1">
			<label for="exampleFormControlTextarea5"> Prénom </label>
			<input type="text" class="form-control" id="exampleFormControlTextarea6" rows="3" name="prenom" required />
		</div>
		<div class="form-group green-border-focus" id="div1_1">
			<label for="exampleFormControlTextarea5"> Email </label>
			<input type="text" class="form-control" id="exampleFormControlTextarea6" rows="3" name="email" required />
		</div>
	</div>

	<!-- Date de naissance, Mot de passe & Confirmation mot de passe -->
	<div class="ligne2">
		<div class="form-group green-border-focus" id="div2_1">
			<label for="exampleFormControlTextarea5"> Date de naissance </label>
			<input type="date" class="form-control" id="exampleFormControlTextarea6" rows="3" placeholder="jj/mm/aaaa" name="dateNais" required />
		</div>
		<div class="form-group green-border-focus" id="div2_1">
			<label for="exampleFormControlTextarea5"> Mot de passe </label>
			<input type="password" class="form-control" id="exampleFormControlTextarea6" rows="3" name="passwd" required />
		</div>
		<div class="form-group green-border-focus" id="div2_1">
			<label for="exampleFormControlTextarea5"> Confirmer le mot de passe </label>
			<input type="password" class="form-control" id="exampleFormControlTextarea6" rows="3" name="passwd2" required />
		</div>
	</div>

	<!-- Téléphone, Code postal & Ville -->
	<div class="ligne3">
		<div class="form-group green-border-focus" id="div3_1">
			<label for="exampleFormControlTextarea5"> Téléphone </label>
			<input type="phone" class="form-control" id="exampleFormControlTextarea6" rows="3" placeholder="" name="telephone" required />
		</div>
		<div class="form-group green-border-focus" id="div3_1">
			<label for="exampleFormControlTextarea5"> Code postal</label>
			<input type="text" class="form-control" id="exampleFormControlTextarea6" rows="3" name="cp" required />
		</div>
		<div class="form-group green-border-focus" id="div3_1">
			<label for="exampleFormControlTextarea5"> Emploi </label>
			<input type="text"  class="form-control" id="exampleFormControlTextarea6" rows="3" name="emploi" required />
		</div>
	</div>

	<!-- Autre & Bio -->
	<div class="ligne4">
		<div class="form-group green-border-focus" id="div4_1">
			<label for="exampleFormControlTextarea5"> Niveau d'étude, Spécialité, Habilitations...  </label>
			<textarea class="form-control" id="exampleFormControlTextarea7" rows="3" name="competence" required ></textarea>
		</div>
		<div class="form-group green-border-focus" id="div4_1">
			<label for="exampleFormControlTextarea5"> BIO  </label>
			<textarea class="form-control" id="exampleFormControlTextarea7" rows="3" name="bio" required ></textarea>
		</div>
	</div>
	<center>
		<input type="submit" class="btn btn-primary btn-lg active" aria-pressed="true" value="Confirmer" />
	</center>
	<?php if(isset($_GET['result'])) { include('resultForm.php'); } ?>
</form>