<center>
	<div class="connexion">
		<h1 id="connexion">Connexion </h1>
	</div>
	<form <?php echo 'action="'. $control .'controller-connexion.php"'; ?> method="post" class="principalconnexion">
		<div class="form-group green-border-focus" id="textarea">
			<label for="exampleFormControlTextarea5"> Email </label>
			<input class="form-control" type="text" name="email" id="exampleFormControlTextarea5" rows="3" />
		</div>
		<div class="form-group green-border-focus" id="textarea">
			<label for="exampleFormControlTextarea5"> Mot de passe </label>
			<input class="form-control" name="passwd" type="password" id="exampleFormControlTextarea5" rows="3"/>
		</div>
		<input class="btn btn-primary btn-lg active" type="submit" aria-pressed="true" value="S'identifier"/> 
	</form>
		<p> <a href="#"> Mot de passe oublié </a></p>
	</div>
	<?php
	if(isset($_GET['result'])) { include('resultForm.php'); } 
	if(isset($_SESSION['Nom'])) { session_destroy(); header('Location: '.$vue.'Home'); }
	?>
	<div class="nocompte">
		<p> Pas encore de compte? <br> <a href="./inscription"> S'inscrire </a></p>
	</div>
</center>