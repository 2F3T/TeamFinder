  <form id="Form" class="mx-5 my-5" method="post">
    <div id="ligne1" class="row">
      <div id="espace" class="col-1"></div>
      <div id="titre1" class="col-11">
        <h1>Identité</h1>
      </div>
    </div>
    <div id="ligne2" class="row">
      <div id="espace" class="col-1"></div>

      <!-- ### CIVILITE ### -->
      <fieldset class="form-group col-3">
        <legend class="col-form-label">Civilité</legend>
        <div class="">
          <div class="form-check">
            <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios1" value="option1" checked>
            <label class="form-check-label" for="gridRadios1">
              Homme
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios2" value="option2">
            <label class="form-check-label" for="gridRadios2">
              Femme
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="gridRadios" id="gridRadios3" value="option3">
            <label class="form-check-label" for="gridRadios3">
              Autre
            </label>
          </div>
        </div>
      </fieldset>

      <div class="col-3">
        <!-- ### NOM ### -->
        <div class="form-group">
          <label for"Nom">Nom</label>
          <input id="Nom" type="text" class="form-control" placeholder="Entrez un nom ...">
        </div>

        <!-- ### PRENOM ### -->
        <div class="form-group">
          <label for"Prenom">Prénom</label>
          <input id="Prenom" type="text" class="form-control" placeholder="Entrez un prénom ...">
        </div>

      </div>

      <div id="espace" class="col-1"></div>

      <div class="col-3">
        <!-- ### DATE DE NAISSANCE ### -->
        <div class="form-group">
          <label for"DateNaissance">Date de naisance</label>
          <input id="DateNaissance" type="text" class="form-control" placeholder="JJ/MM/AAAA" maxlength="10">
        </div>

        <!-- ### PHOTO DE PROFIL ### -->
        <div class="form-group">
          <label for"PhotoProfil">Photo de profil</label>
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="PhotoProfil">
            <label class="custom-file-label" for="customFile">Télécharger une image ...</label>
          </div>
        </div>
      </div>
      <div id="espace" class="col-1"></div>
    </div>

    <div id="ligne3" class="row">
      <div id="espace" class="col-1"></div>
      <div id="titre2" class="col-11">
        <h1>Informations personnelles</h1>
      </div>
    </div>

    <div id="ligne4" class="row">
      <div id="espace" class="col-1"></div>
      <div class="col-3">

        <!-- ### CODE POSTAL ### -->
        <div class="form-group">
          <label for"CodePostal">Code postal</label>
          <input id="CodePostal" type="text" class="form-control" placeholder="Entrez un code postal..." maxlength="5">
        </div>


        <!-- ### TELEPHONE ### -->
        <div class="form-group">
          <label for"NumTel">Numéro de téléphone</label>
          <input id="NumTel" type="text" class="form-control" placeholder="Entrez un numéro ..." maxlength="10">
        </div>
      </div>

      <div class="col-3">
        <!-- ### BIOGRAPHIE ### -->
        <div class="form-group">
          <label for="Bio">Bio</label>
          <textarea id="Bio" class="form-control" placeholder="Entrez un biographie ..."></textarea>
        </div>
      </div>
      <div id="espace" class="col-1"></div>

      <div class="col-1">
        <!-- ### PARCOURS PROFESSIONNEL ET ETUDES ### -->
        <label>Nombre d'experiences</label>
        <select id="SelectExp" class="custom-select" onchange="ChangerNombreExperiences()" required>
          <option value="0" selected>0</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
        </select>
      </div>
      <div id="ExperiencesChoisies" class="col-2"></div>
      <div id="espace" class="col-1"></div>
    </div>

    <div id="ligne5" class="row">
      <div id="espace" class="col-1"></div>
      <div id="titre3" class="col-11">
        <h1>Changement de mot de passe</h1>
      </div>
    </div>

    <div id="ligne6" class="row">
      <div id="espace" class="col-1"></div>
      <!-- ### ANCIEN MOT DE PASSE ### -->
      <div class="col-3">
        <div class="form-group">
          <label for="AncienMDP">Ancien mot de passe</label>
          <input type="password" class="form-control" id="AncienMDP" placeholder="Entrez un mot de passe...">
        </div>
      </div>

      <!-- ### NOUVEAU MOT DE PASSE ### -->
      <div class="col-3">
        <div class="form-group">
          <label for="NouveauMDP">Nouveau mot de passe</label>
          <input type="password" class="form-control" id="NouveauMDP" placeholder="Entrez un mot de passe...">
        </div>
      </div>
      <div id="espace" class="col-5"></div>
    </div>

    <!-- ### BOUTON ENVOI FORMULAIRE ### -->
    <div id="ligne7" class="row">
      <input id="BoutonEnvoyer" class="btn btn-primary mx-auto" type="submit" name="BoutonEnvoyer" value="Confirmer la modification du profil"/>
    </div>
  </form>