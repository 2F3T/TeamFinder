<!-- ### PARTIE RECHERCHE ### -->
<div id="header">
  <form id="FormRecherche" method="get">
    <div id="ligne1" class="row input-group mt-5">
      <div id="espace" class="col-1"></div>
      <!-- ### FILTRER LA RECHERCHE ### -->
      <div id="Filtre" class="col-3">
        <div class="input-group mb-3">
			<form method="get">
				<select class="custom-select" name="categ" id="inputGroupSelect02">
					// <option value="" selected>Choisir un filtre ...</option>
					<?php
					while($categ = $reqCategorie->fetch()) {
						echo '<option value="'.$categ['ID_Categorie'].'">'.$categ['CAT_Nom'].'</option>';
					}
					$reqCategorie->closeCursor();
					?>
				</select>
				  
				<div id="Filtre" class="col-sm-2 mx-auto">
					<button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button>
				</div>
			</form>
        </div>
      </div>

      <div id="espace" class="col-1"></div>

      <!-- ### ZONE DE TEXTE DE RECHERCHE D'UN PROJET ### -->
      <div id="Rechercher" class="col-3">
        <input id="BarreRecherche" type="search" class="form-control ds-input" placeholder="Rechercher un projet ..." autocomplete="off" spellcheck="false">
      </div>

      <!-- ### ESPACE ### -->
      <div id="espace" class="col-2"></div>

      <!-- ### COMMENCER UN PROJET ### -->
      <div id="CommencerProjet" class="col-sm-2 mx-auto">
        <a href="projectcreate.php" class="btn btn-primary">Commencer un projet</a>
      </div>

      <!-- ### ESPACE ### -->
      <div id="espace" class="col-1"></div>
    </div>
  </form>
</div>


<hr id="Separateur" size=8 width="85%"/>

  <div id="main" class="mx-5">
    <div id="ligne2" class="row mx-2">

		<?php
		require ROOT.'project_miniature.php'
		?>
    </div>
  </div>