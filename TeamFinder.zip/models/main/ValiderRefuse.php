<center>
	<center>
		<div class="connexion">
			<h1 id="connexion"> Etude d'une candidature </h1>
		</div>
		<div class="accepteruser">
			Quelqu'un a postulé pour rejoindre votre projet, vous pouvez voir les détails le concernant et sa description en
			<a target="_blank" <?php echo 'href="'.$vue.'profil?user='.htmlentities($_GET['iduser']).'"'; ?>> cliquant ici</a>.
		</div>
		<form method="post" <?php echo 'action="'.$control.'controller-accepterRefuser.php"'; ?> > 
			<div class="valider_refuser">
				<input type="hidden" name="iduser" <?php echo 'value="'.$_GET['iduser'].'"'; ?>>
				<input type="hidden" name="idproj" <?php echo 'value="'.$_GET['idproj'].'"'; ?>>
				<input type="submit" class="btn btn-success" name="accepter" value="Accepter">
				<input type="submit" class="btn btn-danger" name="refuser" value="Refuser">
			</div>
		</form>
    </center>
</center>