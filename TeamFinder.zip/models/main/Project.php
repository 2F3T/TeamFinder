<div id="Back" class="my-5">
      <main>
        <!-- ######   INFOS SUR LE PROJET   ##### -->
        <div class="row" id="ligne1">
          <div class="col-9">
			  <?php
			    $filename = $_SERVER['DOCUMENT_ROOT'].'/core/img/project/'.$ProjetsExist['P_image'];
				$pathImageProject = '';
				
				if (file_exists($filename)) {
					$pathImageProject = 'src="'.$ressource.'img/project/'.$ProjetsExist['P_image'].'"';
				}	
				else{
					$pathImageProject = 'src="'.$ressource.'img/project/base/project_'.$ProjetsExist['P_Categorie'].'.jpg"';
					
				}
				?>
            <img id="image_projet"  <?php echo $pathImageProject ?> alt="Photo du projet" height="150" width="150"/>
            <h1 id="TitreProjet" class="display-4"><?php echo $ProjetsExist['P_Nom']; ?></h1>
            <span>
              <b>Créé par :</b> <span id="Auteur"><?php echo $ProjetsExist['U_Nom'].' '.$ProjetsExist['U_Prenom']; ?></span>
            </span>
            <div id="DescriptionProjet">
              <p><?php echo $ProjetsExist['P_Description']; ?></p>
            </div>
          </div>
          <div class="col-3">
			<form method="post" <?php echo 'action="'.$control.'controller-actionSurProjet.php"'; ?>>
			<input type="hidden" name="proj" <?php echo'value="'.$_GET['proj'].'"' ?> />
            <?php if($_SESSION['Id'] == $ProjetsExist['P_Autheur']) { ?>
				<button class="btn btn-danger btn-lg mx-auto my-5 align-middle" id="Bouton_Postuler" type="submit" name="supp">Supprimer</button>
				<button class="btn btn-primary btn-lg mx-auto my-5 align-middle" id="Bouton_Postuler" type="submit" name="mod">Modifier</button>
            <?php } else {
				$tmp = False;
				while($membreDejaPostul = $reqDejaPostule->fetch()) {
					if($_SESSION['Id'] == $membreDejaPostul['M_User']) {
						$tmp = true;
						break;
					}
				}
				if(!$tmp)
						echo '<button class="btn btn-primary btn-lg mx-auto my-5 align-middle" id="Bouton_Postuler" type="submit" name="post">Postuler</button>';
				$reqDejaPostule->closeCursor();
			}
			?>
			</form>
			<div id="PiecesJointes">
              <details>
                <summary>Pièces jointes</summary>
                <table class="table table-sm">
                  <thead>
                    <tr>
                      <th scope="col">Nom</th>
                      <th scope="col">Taille</th>
                      <th scope="col">Date</th>
                    </tr>
                  </thead>
                  <tbody>
				  <?php
					while($PieceJoin = $reqPieceJoin->fetch()) {
						$filesize = 1;
						if(filesize($_SERVER['DOCUMENT_ROOT'].'/core/app/'.$PieceJoin['PJ_Fichier']))
							$filesize = filesize($_SERVER['DOCUMENT_ROOT'].'/core/app/'.$PieceJoin['PJ_Fichier']);
						print('
						<tr>
						<td><a href="'.$ressource.'app/" download="' . $PieceJoin['PJ_Fichier'] . '">' . $PieceJoin['PJ_Fichier'] . '</a></td>
						<td>' . human_filesize($filesize).'</td>
						<td>' . $PieceJoin['PJ_Date'] . '</td>
						</tr>');
					}
					$reqPieceJoin->closeCursor();
					?>
                  </tbody>
                </table>
              </details>
            </div>
          </div>
        </div>

        <!-- ######   MEMBRES AYANT REJOINT LE PROJET   ##### -->
        <div class="row" id="ligne2">
          <div class="col-6">
            <div id="ListeMembres">
                 <div class="table-responsive table-hover">
                   <table class="table mx-auto">
                     <thead class="thead-dark">
                       <tr>
                         <th scope="col">Nom</th>
                         <th scope="col">Prénom</th>
                         <th scope="col">Fonction</th>
                       </tr>
                     </thead>
						<tbody>						
						<?php
							while($membre = $reqMembres->fetch()) {
								print('
								<tr>
								<td><a href="profil?user=' . $membre['ID_Utilisateur'] . '">' . $membre['U_Nom'] . '</a></td>
								<td><a href="profil?user=' . $membre['ID_Utilisateur'] . '">' . $membre['U_Prenom'] . '</a></td>
								<td><a href="profil?user=' . $membre['ID_Utilisateur'] . '">' . $membre['U_Emploie'] . '</a></td>
								</tr>');
							}
							$reqMembres->closeCursor();
						?>
						</tbody>
                   </table>
                </div>
            </div>
          </div>

        <!-- ######   MEMBRES RECHERCHÉS    ##### -->
          <div class="col-6">
              <div class="container" id="MembresRecherchés">
                <div class="list-group">
                  <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                    <div class="d-flex w-100 justify-content-between">
                      <h5 class="mb-1">Poste à pourvoir n°1</h5>
                    </div>
                    <p class="mb-1">Brève description du rôle recherché.</p>
                  </a>
                  <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                    <div class="d-flex w-100 justify-content-between">
                      <h5 class="mb-1">Poste à pourvoir n°2</h5>
                    </div>
                    <p class="mb-1">Brève description du rôle recherché.</p>
                  </a>
                  <a href="#" class="list-group-item list-group-item-action flex-column align-items-start">
                    <div class="d-flex w-100 justify-content-between">
                      <h5 class="mb-1">Poste à pourvoir n°3</h5>
                    </div>
                    <p class="mb-1">Brève description du rôle recherché.</p>
                  </a>
                </div>
              </div>
          </div>
        </div>

        <!-- #####  SECTION QUESTIONS/RÉPONSES  ##### -->
        <footer>
        <div class="row" id="ligne3">
          <div class="col-12">
            <h2>Questions/Réponses</h2>
          </div>

			<?php
				while($Comm = $reqComm->fetch()) {
					print('
					<div class="col-6">
						<div id="question">
						  '. $Comm['U_Nom'] .' '. $Comm['U_Prenom'] .' :  ' . $Comm['COM_Msg'] . '
						</div>');
						while($Reponse = $reqCommReponse->fetch()) {
							if($Reponse['ID_Com'] = $Comm['ID_Com']){
								print('
								<div id="reponse">
									'. $Reponse['U_Nom'] .' '. $Reponse['U_Prenom'] .' :  ' . $Reponse['CR_Msg'] . '
								</div>');
							}		
						}
					print('</div>');
				}
				
				$reqComm->closeCursor();
				$reqCommReponse->closeCursor();
			?>

        </div>
        </footer>
      </main>
    </div>