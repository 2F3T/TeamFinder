<?php
while($Projets = $reqProjets->fetch()) {
		$filename = $_SERVER['DOCUMENT_ROOT'].'/core/img/project/'.$Projets['P_image'];
		$pathImageProject = '';
		
		if (file_exists($filename)) {
			$pathImageProject = 'src="'.$ressource.'img/project/'.$Projets['P_image'].'"';
		}	
		else{
			$pathImageProject = 'src="'.$ressource.'img/project/base/project_'.$Projets['P_Categorie'].'.jpg"';
		}
		
		print('
		<div class="card mx-auto" style="width: 13rem;">
			<img '. $pathImageProject .' class="card-img-top" alt="Image du projet">
			<div class="card-body">
			  <h5 class="card-title text-center">'.htmlentities($Projets['P_Nom']).'</h5>
			  <a class="btn btn-primary" role="button" href="/Views/project.php?proj='.$Projets['ID_Projet'].'"> Voir le projet </a>
			</div>
		</div>');
}
$reqProjets->closeCursor();
?>