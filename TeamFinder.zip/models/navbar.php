<!-- ######   NAVBAR   ##### -->
    <nav class="navbar navbar-expand-lg navbar-dark blue">
        <a class="navbar-brand" href="./home.php">Team Finder</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                </li>
            </ul>
            <span class="navbar-text white-text">
                <a href="./connexion.php"> <?php echo (isset($_SESSION['Nom']) ? 'Déconnexion' : 'Connexion'); ?> </a>
                <a href="./inscription.php"><?php echo (isset($_SESSION['Nom']) ? '' : ' / S\'inscrire'); ?> </a>
            </span>
        </div>
    </nav>