 <meta charset="UTF-8" />
    <title>TeamFinder</title>
    <!--<link rel="icon" href="favicon.ico">-->
	<?php 
		require $_SERVER['DOCUMENT_ROOT'].'/controllers/fonctions.php';
		session_start();
	?>
    <!-- Bootstrap core CSS -->
    <link <?php echo 'href='.$ressource.'css/bootstrap.min.css';?> rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link <?php echo 'href='.$ressource.'css/bootstrap.min.css';?> rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link <?php echo 'href='.$ressource.'css/mdb.min.css';?> rel="stylesheet">
	
	<link rel="stylesheet" <?php echo 'href='.$ressource.'/css/style.css'?> media="all" type="text/css" />