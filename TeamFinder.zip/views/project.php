<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');		
	?>

	<head>
		<?php
			require ROOT.'/head.php';
			include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-project.php'); 
		?>
		<link rel="stylesheet" <?php echo 'href='.$ressource.'css/Abstract_project.css'?> media="all" type="text/css" />
	</head>

  <body>
    <?php
	   require ROOT.'/navbar.php';
	   require ROOT.'/main/Project.php';
	?>   
  </body>
</html>
