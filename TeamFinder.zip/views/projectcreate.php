<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');		
	?>

	<head>
		<?php
			require ROOT.'/head.php';
			needConnect();
		?>
	  <link rel="stylesheet" <?php echo 'href='.$ressource.'css/Creer_Projet.css'?> media="all" type="text/css" />
	</head>

<body>

	<?php
		require ROOT.'/navbar.php';
		require ROOT.'/main/ProjectCreate.php';	
	?> 
	<script <?php echo 'src='.$ressource.'js/Creer_Projet.js'?> type="text/javascript"></script>
</body>
</html>
