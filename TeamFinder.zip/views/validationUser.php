<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
  </head>
  <body>
    <div class="container" style="margin-top: 100px;">
    <?php if(isset($_GET['result'])) { include('resultForm.php'); } ?>
      <div class="row text-center" id="validation">
        <?php
        if(isset($_GET['token']) && strlen($_GET['token']) == 25) {
			if(isset($_SESSION['Id'])) {header('Location: '.$vue.'profil');} else {
				include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-validInscrit.php');
			}
        } else {
			header('Location: '.$vue.'404');
		}
        ?>
      </div>
    </div>
  </body>
</html>