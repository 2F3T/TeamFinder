<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');
	?>

	<head>
		<?php
		   require ROOT.'/head.php';
		      
		   include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-listeproject.php'); 
		?>
	  <link rel="stylesheet" <?php echo 'href='.$ressource.'css/Abstract_ListeProjet.css'?> type= "text/css" />
	</head>
	
	<body>
		<?php
			require ROOT.'/navbar.php';
			require ROOT.'/main/ListeProject.php';
		?>
	</body>
</html>
