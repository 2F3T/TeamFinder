<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');
	?>

	<head>
		<?php
		   require ROOT.'/head.php';
		?>
	</head>
	
<body>
  <?php
		require ROOT.'/navbar.php';
	?>
	<center>Impossible d'accèder à cette page</center>
</body>
</html>