<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');
	?>

	<head>
		<?php
		   require ROOT.'/head.php';
		?>
	<link rel="stylesheet" <?php echo 'href='.$ressource.'css/Modifier_Profil.css'?> type="text/css" />
	
</head>
<body>
   <?php
		require ROOT.'/navbar.php';
		require ROOT.'/main/ProfilModif.php';
	?>



  <script <?php echo 'src='.$ressource.'js/Modifier_Profil.js'?>></script>
</body>
</html>
