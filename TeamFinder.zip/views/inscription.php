<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');
	?>

	<head>
		<?php
		   require ROOT.'/head.php';
		?>
    </head>

    <body>
       <?php
		   require ROOT.'/navbar_small.php';
		   require ROOT.'/main/Register.php';
		   require ROOT.'/javascript.php';
		?>
    </body>     
</html>