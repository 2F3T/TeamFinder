<!DOCTYPE html>
<html lang="fr">
	<?php
		define('ROOT','../models/');
	?>

	<head>
		<?php
		   require ROOT.'/head.php';
		   include($_SERVER['DOCUMENT_ROOT'].'/controllers/controller-home.php'); 
		?>
    </head>

    <body>
		<?php
			require ROOT.'/navbar.php';
			require ROOT.'/main/Home.php';
			require ROOT.'/javascript.php';
		?>
    </body>     
</html>