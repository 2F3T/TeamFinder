
/*    *   *   *   *   *   *   *   *   *   *   *   *   * **
**              ChangerNombreExperiences()              **
**      CHANGE LE NOMBRE D'EXPERIENCES EN FONCTION      **
**        DU NOMBRE CHOISI PAR L'UTILISATEUR.           **
**      LA FONCTION S'ACTIVE À CHAQUE CHANGEMENT        **
**                  DE LA BALISE SELECT                 **
**    *   *   *   *   *   *   *   *   *   *   *   *   * **/
function ChangerNombreExperiences()
{
  var nombreExp = document.getElementById('SelectExp').value;
  var resultat = "";

  if (nombreExp > 0)
  {
    var ligne1 = '<div class="form-group">';
    var ligne2;
    var ligne3;
    var ligne4 = '</div>';
    for (var i = 0; i < nombreExp; i++)
    {
      ligne2 = '<label for="Experience'+ (i+1) +'">Experience N°'+ (i+1) +'</label>';
      ligne3 = '<input id="Experience'+ (i+1) +'" type="text" class="form-control" placeholder="Entrez le nom de l\'experience ..." maxlength="50"/>';
      resultat += ligne1 + ligne2 + ligne3 + ligne4;
    }
  }

  document.getElementById('ExperiencesChoisies').innerHTML=resultat;
}
