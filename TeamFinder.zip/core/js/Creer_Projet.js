/*    *   *   *   *   *   *   *   *   *   *   *   *   * **
**            ChangerNombreMembresPresents()            **
**      CHANGE LE NOMBRE DE MEMBRES EN FONCTION         **
**        DU NOMBRE CHOISI PAR L'UTILISATEUR.           **
**      LA FONCTION S'ACTIVE À CHAQUE CHANGEMENT        **
**                  DE LA BALISE SELECT                 **
**    *   *   *   *   *   *   *   *   *   *   *   *   * **/
function ChangerNombreMembresPresents()
{
  var nombreMP = document.getElementById('SelectMP').value;
  var resultat = "";

  if (nombreMP > 0)
  {
    var ligne1 = '<div class="input-group">';
    var ligne2 = '<div class="input-group-prepend">';
    var ligne3 = '<span class="input-group-text">Nom / prénom</span>';
    var ligne4 = '</div>';
    var ligne5;
    var ligne6;
    var ligne7 = '</div>';
    for (var i = 0; i < nombreMP; i++)
    {
      ligne5 = '<input type="text" id="NomMP' + (i+1) + '" class="form-control">';
      ligne6 = '<input type="text" id="PrenomMP' + (i+1) + '" class="form-control">';
      resultat += ligne1 + ligne2 + ligne3 + ligne4 + ligne5 + ligne6 + ligne7;
    }
  }

  document.getElementById('MembresPresents').innerHTML=resultat;
}

/*    *   *   *   *   *   *   *   *   *   *   *   *   * **
**            ChangerNombreMembresRecherche()           **
**      CHANGE LE NOMBRE DE MEMBRES EN FONCTION         **
**        DU NOMBRE CHOISI PAR L'UTILISATEUR.           **
**      LA FONCTION S'ACTIVE À CHAQUE CHANGEMENT        **
**                  DE LA BALISE SELECT                 **
**    *   *   *   *   *   *   *   *   *   *   *   *   * **/
function ChangerNombreMembresRecherche()
{
  var nombreMR = document.getElementById('SelectMR').value;
  var resultat = "";

  if (nombreMR > 0)
  {
    var ligne1 = '<div class="input-group">';
    var ligne2 = '<div class="input-group-prepend">';
    var ligne3 = '<span class="input-group-text">Poste / Brève description</span>';
    var ligne4 = '</div>';
    var ligne5;
    var ligne6;
    var ligne7 = '</div>';
    for (var i = 0; i < nombreMR; i++)
    {
      ligne5 = '<input type="text" id="NomMR' + (i+1) + '" class="form-control">';
      ligne6 = '<input type="text" id="PrenomMR' + (i+1) + '" class="form-control">';
      resultat += ligne1 + ligne2 + ligne3 + ligne4 + ligne5 + ligne6 + ligne7;
    }
  }

  document.getElementById('MembresRecherches').innerHTML=resultat;
}
