-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  lun. 14 jan. 2019 à 18:29
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `teamfinder`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

DROP TABLE IF EXISTS `categorie`;
CREATE TABLE IF NOT EXISTS `categorie` (
  `ID_categorie` int(11) NOT NULL AUTO_INCREMENT,
  `CAT_Nom` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_categorie`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categorie`
--

INSERT INTO `categorie` (`ID_categorie`, `CAT_Nom`) VALUES
(1, 'Environnement\r\n'),
(2, 'Informatique\r\n'),
(5, 'Jeux-vidéos\r\n'),
(6, 'Electronique\r\n'),
(7, 'Batiment\r\n'),
(8, 'Automobile\r\n'),
(9, 'Menuiserie\r\n'),
(10, 'Architecture\r\n'),
(11, 'Art & Culture\r\n'),
(12, 'Communication\r\n'),
(13, 'Mecanique\r\n'),
(14, 'Sport\r\n'),
(15, 'Humanitaire\r\n'),
(16, 'Science\r\n'),
(17, 'Autres');

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `ID_Com` int(11) NOT NULL AUTO_INCREMENT,
  `COM_Autheur` int(11) NOT NULL,
  `COM_Msg` text NOT NULL,
  `COM_Projet` int(11) NOT NULL,
  `COM_Date` datetime NOT NULL,
  PRIMARY KEY (`ID_Com`),
  KEY `COM_Autheur` (`COM_Autheur`,`COM_Projet`),
  KEY `COM_Projet` (`COM_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`ID_Com`, `COM_Autheur`, `COM_Msg`, `COM_Projet`, `COM_Date`) VALUES
(1, 2, 'Test de commentaire je pige rien', 1, '2019-01-13 00:00:00'),
(2, 3, 'reponse jsp quoi', 1, '2019-01-13 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `commentairereponse`
--

DROP TABLE IF EXISTS `commentairereponse`;
CREATE TABLE IF NOT EXISTS `commentairereponse` (
  `CR_ID` int(11) NOT NULL,
  `CR_Autheur` int(11) NOT NULL,
  `CR_Msg` text NOT NULL,
  `CR_Projet` int(11) NOT NULL,
  `CR_Date` datetime NOT NULL,
  `ID_Com` int(11) NOT NULL,
  PRIMARY KEY (`CR_ID`),
  KEY `CR_Autheur` (`CR_Autheur`),
  KEY `CR_Projet` (`CR_Projet`),
  KEY `ID_Com` (`ID_Com`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentairereponse`
--

INSERT INTO `commentairereponse` (`CR_ID`, `CR_Autheur`, `CR_Msg`, `CR_Projet`, `CR_Date`, `ID_Com`) VALUES
(1, 2, 'Wesh je test', 1, '2019-01-16 00:00:00', 1),
(2, 2, 'frfefefe', 1, '2019-01-06 00:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `Id_Membre` int(11) NOT NULL AUTO_INCREMENT,
  `M_User` int(11) NOT NULL,
  `M_Projet` int(11) NOT NULL,
  PRIMARY KEY (`Id_Membre`),
  KEY `M_User` (`M_User`,`M_Projet`),
  KEY `M_Projet` (`M_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`Id_Membre`, `M_User`, `M_Projet`) VALUES
(1, 2, 1),
(2, 4, 1),
(3, 5, 1),
(4, 5, 2);

-- --------------------------------------------------------

--
-- Structure de la table `messageprive`
--

DROP TABLE IF EXISTS `messageprive`;
CREATE TABLE IF NOT EXISTS `messageprive` (
  `ID_MP` int(11) NOT NULL AUTO_INCREMENT,
  `MP_Sujet` varchar(255) NOT NULL,
  `MP_Msg` text NOT NULL,
  `MP_Author` int(11) NOT NULL,
  `MP_Destinataire` int(11) NOT NULL,
  `MP_Date` datetime NOT NULL,
  PRIMARY KEY (`ID_MP`),
  KEY `MP_Author` (`MP_Author`,`MP_Destinataire`),
  KEY `MP_Destinataire` (`MP_Destinataire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `piecejointe`
--

DROP TABLE IF EXISTS `piecejointe`;
CREATE TABLE IF NOT EXISTS `piecejointe` (
  `ID_PieceJointe` int(11) NOT NULL AUTO_INCREMENT,
  `PJ_Fichier` varchar(255) NOT NULL,
  `PJ_Projet` int(11) NOT NULL,
  `PJ_Libelle` varchar(255) NOT NULL,
  `PJ_Date` date NOT NULL,
  PRIMARY KEY (`ID_PieceJointe`),
  KEY `PJ_Projet` (`PJ_Projet`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `piecejointe`
--

INSERT INTO `piecejointe` (`ID_PieceJointe`, `PJ_Fichier`, `PJ_Projet`, `PJ_Libelle`, `PJ_Date`) VALUES
(1, 'siteEnCarton.txt', 1, 'test', '2019-01-16'),
(2, 'lol.file', 1, 'c\'est libelle', '2019-01-01');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

DROP TABLE IF EXISTS `projet`;
CREATE TABLE IF NOT EXISTS `projet` (
  `ID_Projet` int(11) NOT NULL AUTO_INCREMENT,
  `P_Nom` varchar(200) NOT NULL,
  `P_Categorie` int(11) NOT NULL,
  `P_NbPlace` smallint(5) UNSIGNED NOT NULL,
  `P_Autheur` int(11) NOT NULL,
  `P_Description` text NOT NULL,
  `P_image` varchar(200) NOT NULL,
  `P_DateCrea` datetime NOT NULL,
  PRIMARY KEY (`ID_Projet`),
  KEY `P_Autheur` (`P_Autheur`),
  KEY `P_Autheur_2` (`P_Autheur`),
  KEY `P_Categorie` (`P_Categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `projet`
--

INSERT INTO `projet` (`ID_Projet`, `P_Nom`, `P_Categorie`, `P_NbPlace`, `P_Autheur`, `P_Description`, `P_image`, `P_DateCrea`) VALUES
(1, 'Gestion de Projet', 2, 4, 2, 'tout rien un peu Et faut mettre beaucoup de caractere sinon c est la merdeEt faut mettre beaucoup de caractere sinon c est la merdeEt faut mettre beaucoup de caractere sinon c est la merdeEt faut mettre beaucoup de caractere sinon c est la merdeEt faut mettre beaucoup de caractere sinon c est la merdeEt faut mettre beaucoup de caractere sinon c est la merde', 'aucune', '2019-01-13 00:00:00'),
(2, 'Chateau en bois', 9, 2, 6, 'contruit un chateau en boiscontruit un chateau en boiscontruit un chateau en boiscontruit un chateau en boiscontruit un chateau en boiscontruit un chateau en boiscontruit un chateau en bois', '', '2019-01-14 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID_Utilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `U_Nom` text NOT NULL,
  `U_Prenom` text NOT NULL,
  `U_Email` varchar(255) NOT NULL,
  `U_Mdp` varchar(255) NOT NULL,
  `U_DateNaissance` datetime NOT NULL,
  `U_Sexe` tinyint(1) NOT NULL,
  `U_Phone` varchar(15) NOT NULL,
  `U_Emploie` varchar(50) NOT NULL,
  `U_CP` varchar(5) DEFAULT NULL,
  `U_Ville` varchar(75) DEFAULT NULL,
  `U_Competence` text NOT NULL,
  `U_Bio` text NOT NULL,
  `U_DateInscrit` date NOT NULL,
  `U_DerniereCo` datetime DEFAULT NULL,
  `U_Token` varchar(25) DEFAULT NULL,
  `U_EmailConfirm` tinyint(1) NOT NULL,
  PRIMARY KEY (`ID_Utilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID_Utilisateur`, `U_Nom`, `U_Prenom`, `U_Email`, `U_Mdp`, `U_DateNaissance`, `U_Sexe`, `U_Phone`, `U_Emploie`, `U_CP`, `U_Ville`, `U_Competence`, `U_Bio`, `U_DateInscrit`, `U_DerniereCo`, `U_Token`, `U_EmailConfirm`) VALUES
(2, 'Recchia', 'François', 'recchiafrancois@gmail.com', 'dffacfcf430c84fcda8c340b2446304a', '1998-11-27 00:00:00', 0, '0679089099', 'Développeur', NULL, NULL, 'Bac+3', 'Le best du best', '2019-01-13', '2019-01-14 17:10:24', '9pbrr;a0l9h0[-|k9bn]3j[hh', 1),
(3, '2F3T', '2F3T', '2F3T@mail.fr', '7186b89d21cdeba34bc75e4e238bbe75', '0001-01-01 00:00:00', 0, '0606060606', 'Company', NULL, NULL, 'tout', 'tout', '2019-01-13', '2019-01-14 10:23:08', '_nly1m}[pfo{_a1zo]|hcc7k_', 0),
(4, 'Genrault', 'Thibaut', 'Genrault@mail.fr', '7186b89d21cdeba34bc75e4e238bbe75', '1997-11-11 00:00:00', 0, '0645454545', 'Chef de Projet', NULL, NULL, 'Licence génie logiciel', 'Css Master', '2019-01-14', NULL, 'mfik|_243h!wd9odlwqa6je-r', 1),
(5, 'Pexoto', 'Florian', 'flopex@mail.fr', '7186b89d21cdeba34bc75e4e238bbe75', '1998-11-11 00:00:00', 0, '0125252525', 'Admin base de données', NULL, NULL, 'BTS', 'Glandeur de type glandu', '2019-01-14', '2019-01-14 14:53:26', 'a!km]v9j-g3]e[d-n95izd029', 1),
(6, 'Bon', 'Jean', 'Jeanbon@saucisson.fr', 'dbeb0d5fd87d411a921113abcb9c9972', '1939-12-14 00:00:00', 0, '0642895738', 'Oui', NULL, NULL, 'Charcutier', 'J\'aime la chatte et le paté', '2019-01-14', '2019-01-14 10:27:22', 'm]due!wuk2ar3qxh!5c6cd5]p', 1),
(8, 'Petrovic', 'Thomas', 'petrovic.thomas@hotmail.com', '7583828054d2819870583c3af75fa0a5', '2019-01-18 00:00:00', 0, '0651069123', 'enToken', NULL, NULL, 'nTo', 'nTok', '2019-01-14', '2019-01-14 17:03:48', '0', 1);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commentaire`
--
ALTER TABLE `commentaire`
  ADD CONSTRAINT `Commentaire_ibfk_1` FOREIGN KEY (`COM_Autheur`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `Commentaire_ibfk_2` FOREIGN KEY (`COM_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `membre`
--
ALTER TABLE `membre`
  ADD CONSTRAINT `Membre_ibfk_1` FOREIGN KEY (`M_User`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `Membre_ibfk_2` FOREIGN KEY (`M_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `messageprive`
--
ALTER TABLE `messageprive`
  ADD CONSTRAINT `MessagePrive_ibfk_1` FOREIGN KEY (`MP_Author`) REFERENCES `utilisateur` (`ID_Utilisateur`),
  ADD CONSTRAINT `MessagePrive_ibfk_2` FOREIGN KEY (`MP_Destinataire`) REFERENCES `utilisateur` (`ID_Utilisateur`);

--
-- Contraintes pour la table `piecejointe`
--
ALTER TABLE `piecejointe`
  ADD CONSTRAINT `PieceJointe_ibfk_1` FOREIGN KEY (`PJ_Projet`) REFERENCES `projet` (`ID_Projet`);

--
-- Contraintes pour la table `projet`
--
ALTER TABLE `projet`
  ADD CONSTRAINT `Projet_ibfk_1` FOREIGN KEY (`P_Autheur`) REFERENCES `utilisateur` (`ID_Utilisateur`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
