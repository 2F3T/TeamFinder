=======================================================================================================
Pour les d�veloppeurs & administrateurs de serveurs web
=======================================================================================================

D�velopp� par l'�quipe 2F3T

Ce projet peut �tre t�l�charg� sur le site:
https://github.com/2F3T/TeamFinder

=======================================================================================================
Qu'est ce que c'est?
=======================================================================================================

TeamFinder est un site web permettant de rechercher des membres et de g�rer ses projets. Vous pouvez
cr�er des comptes utilisateurs et mentionner vos qualifications et comp�tences pour une meilleure
adaptation au projet. Un utilisateur peut �galement cr�er / modifier / supprimer un projet.

=======================================================================================================
Pr� requis syst�me
=======================================================================================================

Le site ne n�cessite pas de pr� requis syst�mes particuliers, juste un navigateur web � jour 
(Mozilla Firefox, Google Chrome), afin d�afficher correctement les Frameworks Bootstrap.
Il n�cessite �galement une base de donn�es phpmyadmin pr�sente sur un serveur web (WAMP / XAMPP).

=======================================================================================================
Comment installer le site
=======================================================================================================

1. Copier le code php depuis l'url https://github.com/2F3T/TeamFinder dans le r�pertoire de votre
serveur web WAMP ou XAMPP.

2. Dans le contr�leur fonction, modifier la variable $host par l�ip de votre serveur web.

3. Installer la base de donn�es gr�ce au script TeamFinder_BDD.sql que vous trouverez
� l'url https://github.com/2F3T/TeamFinder/Base de donn�es.

4. Vous pouvez d�sormais acc�der au site web depuis votre serveur!


Si vous recontrez un probl�me, veuillez contacter un administrateur qui veillera � r�soudre
ce probl�me.
